package com.cg.foodapp.service;

import java.util.List;

import com.cg.foodapp.dto.RestaurantsDTO;

public interface RestaurantsService {

	public RestaurantsDTO addRestaurants(RestaurantsDTO restaurantsDTO);

	public RestaurantsDTO updateRestaurants(RestaurantsDTO restaurantsDTO);

	public boolean deleteRestaurants(RestaurantsDTO restaurantsDTO);

	public RestaurantsDTO getById(int id);

	public List<RestaurantsDTO> findAll();
}
