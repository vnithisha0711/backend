package com.cg.foodapp.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.foodapp.dto.OrdersDTO;
import com.cg.foodapp.entity.Customers;
import com.cg.foodapp.entity.Orders;
import com.cg.foodapp.entity.Restaurants;
import com.cg.foodapp.exceptions.ItemNotAvailableException;
import com.cg.foodapp.repository.OrdersRepository;
import com.cg.foodapp.service.OrdersService;

@Service
public class OrdersServiceImpl implements OrdersService {
	@Autowired
	private OrdersRepository ordersRepository;

	@Override
	public OrdersDTO addOrders(OrdersDTO ordersDTO) {

		Orders orders = new Orders();
		Customers cust = new Customers();
		cust.setCustomerId(ordersDTO.getCustomerId());
		orders.setCustomers(cust);
		orders.setDate(ordersDTO.getDate());
		orders.setDeliveryAddress(ordersDTO.getDeliveryAddress());
		orders.setStatus(ordersDTO.getStatus());
		orders.setCartId(ordersDTO.getCartId());

		Restaurants rest = new Restaurants();
		rest.setId(ordersDTO.getRestaurantId());
		orders.setRestaurants(rest);
		orders.setDate(ordersDTO.getDate());
		orders.setDeliveryAddress(ordersDTO.getDeliveryAddress());
		orders.setStatus(ordersDTO.getStatus());
		orders.setCartId(ordersDTO.getCartId());

		Orders ordersave = ordersRepository.save(orders);
		ordersDTO.setOrderId(ordersave.getOrderId());
		return ordersDTO;

//		Customers customer = customersRepository.findById(ordersDTO.getCustomerId()).get();
//		Restaurants restaurant = restaurantsRepository.findById(ordersDTO.getRestaurantId()).get();

	}

	@Override
	public OrdersDTO updateOrders(OrdersDTO ordersDTO) {

		Orders orders = new Orders();
		Restaurants rest = new Restaurants();
		Customers cust = new Customers();
		rest.setId(ordersDTO.getRestaurantId());
		cust.setCustomerId(ordersDTO.getCustomerId());
		orders.setRestaurants(rest);
		orders.setCustomers(cust);
		orders.setDate(ordersDTO.getDate());
		orders.setDeliveryAddress(ordersDTO.getDeliveryAddress());
		orders.setStatus(ordersDTO.getStatus());
		orders.setOrderId(ordersDTO.getOrderId());
		orders.setCartId(ordersDTO.getCartId());

		ordersRepository.save(orders);
		return ordersDTO;
	}

	@Override
	public boolean deleteOrders(OrdersDTO ordersDTO) {
		Orders orders = new Orders();
		orders.setOrderId(ordersDTO.getOrderId());
		ordersRepository.delete(orders);
		return true;
	}

	@Override
	public OrdersDTO getById(int id) {

		Optional<Orders> orders = ordersRepository.findById(id);
		if (orders.isPresent()) {
			OrdersDTO dto = new OrdersDTO();
			BeanUtils.copyProperties(orders.get(), dto);
			return dto;
		}
		throw new ItemNotAvailableException("Item not Available at this time");
	}

	@Override
	public List<OrdersDTO> findAll() {

		Iterable<Orders> orders = ordersRepository.findAll();
		List<OrdersDTO> dtos = new ArrayList<>();
		for (Orders order : orders) {
			OrdersDTO dto = new OrdersDTO();
			BeanUtils.copyProperties(order, dto);
			dtos.add(dto);
		}
		return dtos;
	}

}
