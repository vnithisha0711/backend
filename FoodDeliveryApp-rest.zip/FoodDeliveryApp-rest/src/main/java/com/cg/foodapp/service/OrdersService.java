package com.cg.foodapp.service;

import java.util.List;

import com.cg.foodapp.dto.OrdersDTO;

public interface OrdersService {

	public OrdersDTO addOrders(OrdersDTO ordersDTO);

	public OrdersDTO updateOrders(OrdersDTO ordersDTO);

	public boolean deleteOrders(OrdersDTO ordersDTO);

	public OrdersDTO getById(int id);

	public List<OrdersDTO> findAll();

}
