package com.cg.foodapp.exceptions;

public class ItemNotAvailableException extends RuntimeException{


	private static final long serialVersionUID = 1L;

	public ItemNotAvailableException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ItemNotAvailableException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
